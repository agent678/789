﻿using DemoEx.Data;
using DemoEx.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Windows;

namespace DemoEx
{
    public partial class AddEditProductWindow : Window
    {
        private ProductItem _product;

        public AddEditProductWindow(ProductItem product)
        {
            InitializeComponent();

            _product = product;

            if (_product != null)
            {
                ArticleTextBox.Text = _product.Article;
                ArticleTextBox.IsReadOnly = true;

                ProductNameTextBox.Text = _product.ProductName;
                CategoryTextBox.Text = _product.Category;
                DescriptionTextBox.Text = _product.Description;
                ManufacturerTextBox.Text = _product.Manufacturer;
                SupplierTextBox.Text = _product.Supplier;
                PriceTextBox.Text = _product.Price.ToString();
                UnitTextBox.Text = _product.Unit;
                StockQuantityTextBox.Text = _product.StockQuantity.ToString();
                DiscountTextBox.Text = _product.Discount.ToString();
                PhotoTextBox.Text = _product.Photo;
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ArticleTextBox.Text) ||
                string.IsNullOrWhiteSpace(ProductNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(PriceTextBox.Text) ||
                string.IsNullOrWhiteSpace(StockQuantityTextBox.Text) ||
                string.IsNullOrWhiteSpace(DiscountTextBox.Text))
            {
                MessageBox.Show(
                    "Заполните обязательные поля: артикул, название, цена, количество и скидка.",
                    "Ошибка ввода",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            decimal price;
            int stockQuantity;
            decimal discount;

            if (!decimal.TryParse(PriceTextBox.Text, out price) || price < 0)
            {
                MessageBox.Show("Цена должна быть числом и не может быть отрицательной.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(StockQuantityTextBox.Text, out stockQuantity) || stockQuantity < 0)
            {
                MessageBox.Show("Количество должно быть целым числом и не может быть отрицательным.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!decimal.TryParse(DiscountTextBox.Text, out discount) || discount < 0)
            {
                MessageBox.Show("Скидка должна быть числом и не может быть отрицательной.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (SqlConnection connection = DbHelper.GetConnection())
                {
                    connection.Open();

                    if (_product == null)
                    {
                        string insertQuery = @"
                        INSERT INTO FurnitureProducts
                        (Article, ProductName, Unit, Price, Supplier, Manufacturer, Category, Discount, StockQuantity, Description, Photo)
                        VALUES
                        (@article, @productName, @unit, @price, @supplier, @manufacturer, @category, @discount, @stockQuantity, @description, @photo)";

                        SqlCommand command = new SqlCommand(insertQuery, connection);
                        FillCommand(command, price, stockQuantity, discount);
                        command.ExecuteNonQuery();
                    }
                    else
                    {
                        string updateQuery = @"
                        UPDATE FurnitureProducts SET
                            ProductName = @productName,
                            Unit = @unit,
                            Price = @price,
                            Supplier = @supplier,
                            Manufacturer = @manufacturer,
                            Category = @category,
                            Discount = @discount,
                            StockQuantity = @stockQuantity,
                            Description = @description,
                            Photo = @photo
                        WHERE Article = @article";

                        SqlCommand command = new SqlCommand(updateQuery, connection);
                        FillCommand(command, price, stockQuantity, discount);
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show(
                    "Данные сохранены.",
                    "Информация",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Ошибка при сохранении товара:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void FillCommand(SqlCommand command, decimal price, int stockQuantity, decimal discount)
        {
            command.Parameters.AddWithValue("@article", ArticleTextBox.Text.Trim());
            command.Parameters.AddWithValue("@productName", ProductNameTextBox.Text.Trim());
            command.Parameters.AddWithValue("@unit", UnitTextBox.Text.Trim());
            command.Parameters.AddWithValue("@price", price);
            command.Parameters.AddWithValue("@supplier", SupplierTextBox.Text.Trim());
            command.Parameters.AddWithValue("@manufacturer", ManufacturerTextBox.Text.Trim());
            command.Parameters.AddWithValue("@category", CategoryTextBox.Text.Trim());
            command.Parameters.AddWithValue("@discount", discount);
            command.Parameters.AddWithValue("@stockQuantity", stockQuantity);
            command.Parameters.AddWithValue("@description", DescriptionTextBox.Text.Trim());
            command.Parameters.AddWithValue("@photo", PhotoTextBox.Text.Trim());
        }
    }
}