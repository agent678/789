﻿using Microsoft.Data.SqlClient;

namespace DemoEx.Data
{
    public static class DbHelper
    {
        public static string ConnectionString =
            @"Server= localhost;Database=MebelStore;Trusted_Connection=True;TrustServerCertificate=True";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}

