﻿using DemoEx.Data;
using DemoEx.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Windows;

namespace DemoEx
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox.Text.Trim();
            string password = PasswordBox.Password.Trim();

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show(
                    "Введите логин и пароль.",
                    "Ошибка входа",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            try
            {
                using (SqlConnection connection = DbHelper.GetConnection())
                {
                    connection.Open();

                    string query = @"
                        SELECT 
                            u.UserID,
                            u.RoleID,
                            u.FullName,
                            u.Login,
                            u.Password,
                            r.RoleName
                        FROM Users u
                        INNER JOIN Roles r ON u.RoleID = r.RoleID
                        WHERE u.Login = @login AND u.Password = @password";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@login", login);
                    command.Parameters.AddWithValue("@password", password);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            User currentUser = new User
                            {
                                UserID = Convert.ToInt32(reader["UserID"]),
                                RoleID = Convert.ToInt32(reader["RoleID"]),
                                FullName = reader["FullName"].ToString(),
                                Login = reader["Login"].ToString(),
                                Password = reader["Password"].ToString(),
                                RoleName = reader["RoleName"].ToString()
                            };

                            OpenProductWindow(currentUser);
                        }
                        else
                        {
                            MessageBox.Show(
                                "Неверный логин или пароль.",
                                "Ошибка входа",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Ошибка подключения к базе данных:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void GuestButton_Click(object sender, RoutedEventArgs e)
        {
            User guestUser = new User
            {
                UserID = 0,
                RoleID = 0,
                FullName = "Гость",
                Login = "guest",
                Password = "",
                RoleName = "Гость"
            };

            OpenProductWindow(guestUser);
        }

        private void OpenProductWindow(User user)
        {
            ProductsWindow productsWindow = new ProductsWindow(user);
            productsWindow.Show();
            Close();
        }
    }
}