﻿using System;
using System.IO;
using System.Windows.Media.Imaging;

namespace DemoEx.Models
{
    public class ProductItem
    {
        public string Article { get; set; }
        public string ProductName { get; set; }
        public string Unit { get; set; }
        public decimal Price { get; set; }
        public string Supplier { get; set; }
        public string Manufacturer { get; set; }
        public string Category { get; set; }
        public decimal Discount { get; set; }
        public int StockQuantity { get; set; }
        public string Description { get; set; }
        public string Photo { get; set; }

        public decimal FinalPrice
        {
            get
            {
                return Price - (Price * Discount / 100);
            }
        }

        public BitmapImage ProductImage
        {
            get
            {
                try
                {
                    string projectImagesPath =
                        @"C:\Users\mlune\Desktop\DemoEx\DemoEx\Images\";

                    string fileName = string.IsNullOrWhiteSpace(Photo)
                        ? "1.jpg"
                        : Photo.Trim();

                    string fullPath = Path.Combine(projectImagesPath, fileName);

                    if (!File.Exists(fullPath))
                    {
                        return null;
                    }

                    BitmapImage image = new BitmapImage();

                    image.BeginInit();
                    image.UriSource = new Uri(fullPath, UriKind.Absolute);
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
                    image.EndInit();

                    return image;
                }
                catch
                {
                    return null;
                }
            }
        }

        public bool HasDiscount
        {
            get { return Discount > 0; }
        }

        public bool HasBigDiscount
        {
            get { return Discount > 15; }
        }

        public bool IsOutOfStock
        {
            get { return StockQuantity <= 0; }
        }
    }
}