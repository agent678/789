﻿using DemoEx.Data;
using DemoEx.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace DemoEx
{
    public partial class ProductsWindow : Window
    {
        private User _currentUser;
        private List<ProductItem> _allProducts = new List<ProductItem>();

        public ProductsWindow(User user)
        {
            InitializeComponent();

            _currentUser = user;
            UserInfoTextBlock.Text = $"{user.FullName} | {user.RoleName}";

            if (SortComboBox.Items.Count > 0)
            {
                SortComboBox.SelectedIndex = 0;
            }

            if (DiscountComboBox.Items.Count > 0)
            {
                DiscountComboBox.SelectedIndex = 0;
            }

            if (user.RoleName == "Гость" || user.RoleName == "Авторизированный клиент")
            {
                ManagerPanel.Visibility = Visibility.Collapsed;
            }

            if (user.RoleName != "Администратор")
            {
                AdminPanel.Visibility = Visibility.Collapsed;
            }

            LoadProducts();
        }

        private void LoadProducts()
        {
            _allProducts.Clear();

            try
            {
                using (SqlConnection connection = DbHelper.GetConnection())
                {
                    connection.Open();

                    string query = @"
                        SELECT
                            Article,
                            ProductName,
                            Unit,
                            Price,
                            Supplier,
                            Manufacturer,
                            Category,
                            Discount,
                            StockQuantity,
                            Description,
                            Photo
                        FROM FurnitureProducts";

                    SqlCommand command = new SqlCommand(query, connection);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ProductItem product = new ProductItem();

                            // Read string columns safely if they exist
                            product.Article = reader.HasColumn("Article") && !reader.IsDBNull(reader.GetOrdinal("Article"))
                                ? reader.GetString(reader.GetOrdinal("Article")).Trim()
                                : string.Empty;

                            product.ProductName = reader.HasColumn("ProductName") && !reader.IsDBNull(reader.GetOrdinal("ProductName"))
                                ? reader.GetString(reader.GetOrdinal("ProductName")).Trim()
                                : string.Empty;

                            product.Unit = reader.HasColumn("Unit") && !reader.IsDBNull(reader.GetOrdinal("Unit"))
                                ? reader.GetString(reader.GetOrdinal("Unit")).Trim()
                                : string.Empty;

                            // Numeric columns with safe conversion
                            if (reader.HasColumn("Price") && !reader.IsDBNull(reader.GetOrdinal("Price")))
                            {
                                try { product.Price = Convert.ToDecimal(reader["Price"]); } catch { product.Price = 0; }
                            }

                            product.Supplier = reader.HasColumn("Supplier") && !reader.IsDBNull(reader.GetOrdinal("Supplier"))
                                ? reader.GetString(reader.GetOrdinal("Supplier")).Trim()
                                : string.Empty;

                            product.Manufacturer = reader.HasColumn("Manufacturer") && !reader.IsDBNull(reader.GetOrdinal("Manufacturer"))
                                ? reader.GetString(reader.GetOrdinal("Manufacturer")).Trim()
                                : string.Empty;

                            product.Category = reader.HasColumn("Category") && !reader.IsDBNull(reader.GetOrdinal("Category"))
                                ? reader.GetString(reader.GetOrdinal("Category")).Trim()
                                : string.Empty;

                            if (reader.HasColumn("Discount") && !reader.IsDBNull(reader.GetOrdinal("Discount")))
                            {
                                try { product.Discount = Convert.ToDecimal(reader["Discount"]); } catch { product.Discount = 0; }
                            }

                            if (reader.HasColumn("StockQuantity") && !reader.IsDBNull(reader.GetOrdinal("StockQuantity")))
                            {
                                try { product.StockQuantity = Convert.ToInt32(reader["StockQuantity"]); } catch { product.StockQuantity = 0; }
                            }

                            product.Description = reader.HasColumn("Description") && !reader.IsDBNull(reader.GetOrdinal("Description"))
                                ? reader.GetString(reader.GetOrdinal("Description")).Trim()
                                : string.Empty;

                            product.Photo = reader.HasColumn("Photo") && !reader.IsDBNull(reader.GetOrdinal("Photo"))
                                ? reader.GetString(reader.GetOrdinal("Photo")).Trim()
                                : string.Empty;

                            _allProducts.Add(product);
                        }
                    }
                }

                ApplyFilters();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось загрузить товары из базы данных:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void ApplyFilters()
        {
            if (ProductsDataGrid == null)
            {
                return;
            }

            IEnumerable<ProductItem> result = _allProducts;

            string searchText = "";

            if (SearchTextBox != null)
            {
                searchText = SearchTextBox.Text.Trim().ToLower();
            }

            if (!string.IsNullOrWhiteSpace(searchText))
            {
                result = result.Where(p =>
                    p.Article.ToLower().Contains(searchText) ||
                    p.ProductName.ToLower().Contains(searchText) ||
                    p.Category.ToLower().Contains(searchText) ||
                    p.Description.ToLower().Contains(searchText) ||
                    p.Manufacturer.ToLower().Contains(searchText) ||
                    p.Supplier.ToLower().Contains(searchText) ||
                    p.Unit.ToLower().Contains(searchText));
            }

            string discountFilter = "Все диапазоны";

            if (DiscountComboBox != null && DiscountComboBox.SelectedItem != null)
            {
                ComboBoxItem discountItem = DiscountComboBox.SelectedItem as ComboBoxItem;

                if (discountItem != null && discountItem.Content != null)
                {
                    discountFilter = discountItem.Content.ToString();
                }
            }

            if (discountFilter == "0-10,99%")
            {
                result = result.Where(p => p.Discount >= 0 && p.Discount <= 10.99m);
            }
            else if (discountFilter == "11-14,99%")
            {
                result = result.Where(p => p.Discount >= 11 && p.Discount <= 14.99m);
            }
            else if (discountFilter == "15% и более")
            {
                result = result.Where(p => p.Discount >= 15);
            }

            string sort = "Без сортировки";

            if (SortComboBox != null && SortComboBox.SelectedItem != null)
            {
                ComboBoxItem sortItem = SortComboBox.SelectedItem as ComboBoxItem;

                if (sortItem != null && sortItem.Content != null)
                {
                    sort = sortItem.Content.ToString();
                }
            }

            if (sort == "Цена по возрастанию")
            {
                result = result.OrderBy(p => p.Price);
            }
            else if (sort == "Цена по убыванию")
            {
                result = result.OrderByDescending(p => p.Price);
            }
            else if (sort == "Количество по возрастанию")
            {
                result = result.OrderBy(p => p.StockQuantity);
            }
            else if (sort == "Количество по убыванию")
            {
                result = result.OrderByDescending(p => p.StockQuantity);
            }

            ProductsDataGrid.ItemsSource = result.ToList();
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void SortComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void DiscountComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            AddEditProductWindow window = new AddEditProductWindow(null);
            window.ShowDialog();
            LoadProducts();
        }

        private void EditProductButton_Click(object sender, RoutedEventArgs e)
        {
            ProductItem selectedProduct = ProductsDataGrid.SelectedItem as ProductItem;

            if (selectedProduct == null)
            {
                MessageBox.Show(
                    "Выберите товар для редактирования.",
                    "Предупреждение",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            AddEditProductWindow window = new AddEditProductWindow(selectedProduct);
            window.ShowDialog();
            LoadProducts();
        }

        private void DeleteProductButton_Click(object sender, RoutedEventArgs e)
        {
            ProductItem selectedProduct = ProductsDataGrid.SelectedItem as ProductItem;

            if (selectedProduct == null)
            {
                MessageBox.Show(
                    "Выберите товар для удаления.",
                    "Предупреждение",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            MessageBoxResult result = MessageBox.Show(
                "Вы действительно хотите удалить выбранный товар?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using (SqlConnection connection = DbHelper.GetConnection())
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM OrderProducts WHERE Article = @article";

                    SqlCommand checkCommand = new SqlCommand(checkQuery, connection);
                    checkCommand.Parameters.AddWithValue("@article", selectedProduct.Article);

                    int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                    if (count > 0)
                    {
                        MessageBox.Show(
                            "Нельзя удалить товар, который присутствует в заказе.",
                            "Удаление запрещено",
                            MessageBoxButton.OK,
                            MessageBoxImage.Error);

                        return;
                    }

                    string deleteQuery = "DELETE FROM FurnitureProducts WHERE Article = @article";

                    SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection);
                    deleteCommand.Parameters.AddWithValue("@article", selectedProduct.Article);
                    deleteCommand.ExecuteNonQuery();
                }

                MessageBox.Show(
                    "Товар удалён.",
                    "Информация",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Ошибка при удалении товара:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow loginWindow = new MainWindow();
            loginWindow.Show();
            Close();
        }
    }
}