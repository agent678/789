/*
    Мебель Стор  — схема базы данных (3НФ) + загрузка реальных данных из Приложения 2
    СУБД: Microsoft SQL Server (на экзамене — сервер по IP, SQL Server Authentication)
    Соглашение об именовании: PascalCase, ед. число для таблиц-сущностей,
    первичный ключ = Table + Id, внешний ключ называется так же, как PK в родителе.

    Это финальная версия, заменяет черновик (mebelKing). Исправлены относительно черновика:
      1) Price  INT -> DECIMAL(10,2)  — задание прямо требует "сотые части" цены
      2) Discount INT -> DECIMAL(5,2) — границы фильтра заданы с сотыми (10,99% / 14,99%)
      3) [Order]/[User] -> Orders/Users — ORDER и USER зарезервированные слова T-SQL
      4) Creator -> Manufacturers, Delivery -> Suppliers — старые имена не отражали назначение
      5) CountOnSclade -> StockQuantity — опечатка/транслит, не по соглашению об именовании
      6) Роль "Авторизованный клиент" -> "Авторизированный клиент" — как в исходном user_import.xlsx
      7) StatusOrder сохранён как справочник OrderStatuses (это было хорошим решением в черновике)
      8) Все справочные таблицы используют один и тот же паттерн (Id IDENTITY + Name)
*/

IF DB_ID('MebelStore') IS NULL
BEGIN
    CREATE DATABASE MebelStore;
END
GO

USE MebelStore;
GO

-- ===================== Справочники =====================

CREATE TABLE Roles (
    RoleId      INT IDENTITY(1,1) PRIMARY KEY,
    RoleName    NVARCHAR(50) NOT NULL UNIQUE
);
GO

CREATE TABLE Categories (
    CategoryId      INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName    NVARCHAR(100) NOT NULL UNIQUE
);
GO

CREATE TABLE Manufacturers (
    ManufacturerId      INT IDENTITY(1,1) PRIMARY KEY,
    ManufacturerName    NVARCHAR(150) NOT NULL UNIQUE
);
GO

CREATE TABLE Suppliers (
    SupplierId      INT IDENTITY(1,1) PRIMARY KEY,
    SupplierName    NVARCHAR(150) NOT NULL UNIQUE
);
GO

CREATE TABLE Units (
    UnitId      INT IDENTITY(1,1) PRIMARY KEY,
    UnitName    NVARCHAR(20) NOT NULL UNIQUE
);
GO

CREATE TABLE OrderStatuses (
    OrderStatusId   INT IDENTITY(1,1) PRIMARY KEY,
    StatusName      NVARCHAR(50) NOT NULL UNIQUE
);
GO

CREATE TABLE PickupPoints (
    PickupPointId   INT IDENTITY(1,1) PRIMARY KEY,
    Address         NVARCHAR(250) NOT NULL UNIQUE
);
GO

-- ===================== Пользователи =====================

CREATE TABLE Users (
    UserId          INT IDENTITY(1,1) PRIMARY KEY,
    FullName        NVARCHAR(150) NOT NULL,
    Login           NVARCHAR(150) NOT NULL UNIQUE,
    Password        NVARCHAR(100) NOT NULL,           -- открытый текст: хеширование не требуется (подтверждено пользователем)
    RoleId          INT NOT NULL,
    CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleId) REFERENCES Roles(RoleId)
);
GO

-- ===================== Товары =====================

CREATE TABLE Products (
    ProductId       INT IDENTITY(1,1) PRIMARY KEY,
    Article         NVARCHAR(20) NOT NULL UNIQUE,
    ProductName     NVARCHAR(300) NOT NULL,
    UnitId          INT NOT NULL,
    Price           DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
    StockQuantity   INT NOT NULL CHECK (StockQuantity >= 0),
    Discount        DECIMAL(5,2) NOT NULL DEFAULT 0 CHECK (Discount >= 0 AND Discount <= 100),
    Description     NVARCHAR(MAX) NULL,
    PhotoPath       NVARCHAR(260) NULL,                -- NULL/пусто -> в приложении подставляется picture.png
    CategoryId      INT NOT NULL,
    ManufacturerId  INT NOT NULL,
    SupplierId      INT NOT NULL,
    CONSTRAINT FK_Products_Units          FOREIGN KEY (UnitId)         REFERENCES Units(UnitId),
    CONSTRAINT FK_Products_Categories     FOREIGN KEY (CategoryId)     REFERENCES Categories(CategoryId),
    CONSTRAINT FK_Products_Manufacturers  FOREIGN KEY (ManufacturerId) REFERENCES Manufacturers(ManufacturerId),
    CONSTRAINT FK_Products_Suppliers      FOREIGN KEY (SupplierId)     REFERENCES Suppliers(SupplierId)
);
GO

-- ===================== Заказы =====================

CREATE TABLE Orders (
    OrderId         INT IDENTITY(1,1) PRIMARY KEY,
    OrderDate       DATE NOT NULL,
    DeliveryDate    DATE NOT NULL,
    PickupCode      INT NOT NULL,
    OrderStatusId   INT NOT NULL,
    ClientId        INT NOT NULL,
    PickupPointId   INT NOT NULL,
    CONSTRAINT FK_Orders_OrderStatuses  FOREIGN KEY (OrderStatusId) REFERENCES OrderStatuses(OrderStatusId),
    CONSTRAINT FK_Orders_Users          FOREIGN KEY (ClientId)      REFERENCES Users(UserId),
    CONSTRAINT FK_Orders_PickupPoints   FOREIGN KEY (PickupPointId) REFERENCES PickupPoints(PickupPointId)
);
GO

CREATE TABLE OrderItems (
    OrderItemId     INT IDENTITY(1,1) PRIMARY KEY,
    OrderId         INT NOT NULL,
    ProductId       INT NOT NULL,
    Quantity        INT NOT NULL CHECK (Quantity > 0),
    CONSTRAINT FK_OrderItems_Orders    FOREIGN KEY (OrderId)   REFERENCES Orders(OrderId),
    CONSTRAINT FK_OrderItems_Products  FOREIGN KEY (ProductId) REFERENCES Products(ProductId),
    CONSTRAINT UQ_OrderItems_OrderProduct UNIQUE (OrderId, ProductId)
);
GO

-- ===================== Справочные данные =====================

INSERT INTO Roles (RoleName) VALUES
    (N'Администратор'),
    (N'Менеджер'),
    (N'Авторизированный клиент');
GO

INSERT INTO Categories (CategoryName) VALUES
    (N'Прихожая'), (N'Диван'), (N'Обувница'), (N'Пуф'), (N'Полка'), (N'Стул');
GO

INSERT INTO Manufacturers (ManufacturerName) VALUES
    (N'SVМЕБЕЛЬ'), (N'Мебелони'), (N'Инвуд'), (N'RIDBERG');
GO

INSERT INTO Suppliers (SupplierName) VALUES
    (N'Стройландия'), (N'Кромма'), (N'ЗолотоеРуно'), (N'KRYLOVMANUFACTURA');
GO

INSERT INTO Units (UnitName) VALUES (N'шт.');
GO

INSERT INTO OrderStatuses (StatusName) VALUES (N'Новый'), (N'Завершен');
GO

-- ===================== Товары (Tovar.xlsx, 10 строк) =====================

INSERT INTO Products (Article, ProductName, UnitId, Price, StockQuantity, Discount, Description, PhotoPath, CategoryId, ManufacturerId, SupplierId)
SELECT N'А112Т4', N'Прихожая Фаворит 1 1420х2056х352ммм Дуб Делано/Цемент Светлый SV-М 1 шт', u.UnitId, 9577.00, 0, 10.00,
       N'Удивительно функциональная и практичная прихожая Фаворит 1, обладая характерными чертами Скандинавского стиля, выглядит эффектно и способна задать тон интерьеру дома, встречая вас и ваших гостей.',
       N'1.jpg', c.CategoryId, m.ManufacturerId, s.SupplierId
FROM Units u, Categories c, Manufacturers m, Suppliers s
WHERE u.UnitName = N'шт.' AND c.CategoryName = N'Прихожая' AND m.ManufacturerName = N'SVМЕБЕЛЬ' AND s.SupplierName = N'Стройландия';

INSERT INTO Products (Article, ProductName, UnitId, Price, StockQuantity, Discount, Description, PhotoPath, CategoryId, ManufacturerId, SupplierId)
SELECT N'G843H5', N'Прихожая в коридор Твист с зеркалом мебель со шкафами, 120х37х202 см', u.UnitId, 8803.00, 9, 25.00,
       N'Этот стеллаж со шкафом в прихожую комнату станет отличным элементом для вашего интерьера. Мебель для дома обеспечивает удобное хранение перчаток, шапок, зонтов, сумок и других аксессуаров.',
       N'2.jpg', c.CategoryId, m.ManufacturerId, s.SupplierId
FROM Units u, Categories c, Manufacturers m, Suppliers s
WHERE u.UnitName = N'шт.' AND c.CategoryName = N'Прихожая' AND m.ManufacturerName = N'Мебелони' AND s.SupplierName = N'Стройландия';

INSERT INTO Products (Article, ProductName, UnitId, Price, StockQuantity, Discount, Description, PhotoPath, CategoryId, ManufacturerId, SupplierId)
SELECT N'D325D4', N'Угловой диван Кромма Инвуд Лайт, серый двухместный диван, Velutto 32', u.UnitId, 29125.00, 12, 5.00,
       N'Угловой диван Инвуд Лайт 2 - стильный и комфортный диван подойдет для комнаты любого размера.',
       N'3.jpg', c.CategoryId, m.ManufacturerId, s.SupplierId
FROM Units u, Categories c, Manufacturers m, Suppliers s
WHERE u.UnitName = N'шт.' AND c.CategoryName = N'Диван' AND m.ManufacturerName = N'Инвуд' AND s.SupplierName = N'Кромма';

INSERT INTO Products (Article, ProductName, UnitId, Price, StockQuantity, Discount, Description, PhotoPath, CategoryId, ManufacturerId, SupplierId)
SELECT N'S432T5', N'Обувница RIDBERG, с вешалкой, стальная, 170x60x26 см, 5 полок, вместимость до 15 пар', u.UnitId, 885.00, 15, 15.00,
       N'Обувница Ridberg с 5 полками и вешалкой - идеальное решение для организации хранения обуви в прихожей или гардеробной.',
       N'4.jpg', c.CategoryId, m.ManufacturerId, s.SupplierId
FROM Units u, Categories c, Manufacturers m, Suppliers s
WHERE u.UnitName = N'шт.' AND c.CategoryName = N'Обувница' AND m.ManufacturerName = N'RIDBERG' AND s.SupplierName = N'Кромма';

INSERT INTO Products (Article, ProductName, UnitId, Price, StockQuantity, Discount, Description, PhotoPath, CategoryId, ManufacturerId, SupplierId)
SELECT N'F325D4', N'Диван, Прямой диван, Диван-кровать Сити темно-коричневый. Квест-33', u.UnitId, 14322.00, 3, 18.00,
       N'Прямой диван-кровать Сити - это современное и функциональное решение для вашего дома.',
       N'5.jpg', c.CategoryId, m.ManufacturerId, s.SupplierId
FROM Units u, Categories c, Manufacturers m, Suppliers s
WHERE u.UnitName = N'шт.' AND c.CategoryName = N'Диван' AND m.ManufacturerName = N'Инвуд' AND s.SupplierName = N'ЗолотоеРуно';

INSERT INTO Products (Article, ProductName, UnitId, Price, StockQuantity, Discount, Description, PhotoPath, CategoryId, ManufacturerId, SupplierId)
SELECT N'G432G6', N'Пуф трансформер кровать раскладушка светло-коричневый велюр', u.UnitId, 6149.00, 3, 22.00,
       N'Пуф трансформер 5в1 представляет собой уникальное сочетание функций, выступая в качестве пуфика, столика, кресла, шезлонга и дополнительного спального места.',
       N'6.jpg', c.CategoryId, m.ManufacturerId, s.SupplierId
FROM Units u, Categories c, Manufacturers m, Suppliers s
WHERE u.UnitName = N'шт.' AND c.CategoryName = N'Пуф' AND m.ManufacturerName = N'Инвуд' AND s.SupplierName = N'KRYLOVMANUFACTURA';

INSERT INTO Products (Article, ProductName, UnitId, Price, StockQuantity, Discount, Description, PhotoPath, CategoryId, ManufacturerId, SupplierId)
SELECT N'H542F5', N'Диван, Прямой диван, диван кровать, Рио симпл механизм Пантограф. Симпл-16', u.UnitId, 20708.00, 5, 4.00,
       N'Диван Рио симпл от "Золотое Руно" - это сочетание комфорта, функциональности и стильного дизайна.',
       N'7.jpg', c.CategoryId, m.ManufacturerId, s.SupplierId
FROM Units u, Categories c, Manufacturers m, Suppliers s
WHERE u.UnitName = N'шт.' AND c.CategoryName = N'Диван' AND m.ManufacturerName = N'Инвуд' AND s.SupplierName = N'ЗолотоеРуно';

INSERT INTO Products (Article, ProductName, UnitId, Price, StockQuantity, Discount, Description, PhotoPath, CategoryId, ManufacturerId, SupplierId)
SELECT N'C346F5', N'Полка настенная ромб Лофт, черная, 40 см', u.UnitId, 2843.00, 4, 5.00,
       N'Полочки для цветов в стиле лофт. Подойдут как для цветов, так и в качестве декоративного элемента. Полки подойдут для дома, офиса, кафе, ресторана.',
       N'8.jpg', c.CategoryId, m.ManufacturerId, s.SupplierId
FROM Units u, Categories c, Manufacturers m, Suppliers s
WHERE u.UnitName = N'шт.' AND c.CategoryName = N'Полка' AND m.ManufacturerName = N'RIDBERG' AND s.SupplierName = N'KRYLOVMANUFACTURA';

INSERT INTO Products (Article, ProductName, UnitId, Price, StockQuantity, Discount, Description, PhotoPath, CategoryId, ManufacturerId, SupplierId)
SELECT N'F256G6', N'Стулья для кухни', u.UnitId, 4760.00, 2, 6.00,
       N'Набор из четырех стульев в лофт-дизайне станет любимой мебелью для отдыха и подойдет для взрослых и детей.',
       N'9.jpg', c.CategoryId, m.ManufacturerId, s.SupplierId
FROM Units u, Categories c, Manufacturers m, Suppliers s
WHERE u.UnitName = N'шт.' AND c.CategoryName = N'Стул' AND m.ManufacturerName = N'RIDBERG' AND s.SupplierName = N'KRYLOVMANUFACTURA';

INSERT INTO Products (Article, ProductName, UnitId, Price, StockQuantity, Discount, Description, PhotoPath, CategoryId, ManufacturerId, SupplierId)
SELECT N'J532V5', N'Магнитная полка, для холодильника, металл, 3шт, универсальная, чёрная', u.UnitId, 1387.00, 6, 8.00,
       N'Магнитная полка для холодильника - это удобный и практичный аксессуар, который поможет организовать пространство в вашем доме.',
       N'10.jpg', c.CategoryId, m.ManufacturerId, s.SupplierId
FROM Units u, Categories c, Manufacturers m, Suppliers s
WHERE u.UnitName = N'шт.' AND c.CategoryName = N'Полка' AND m.ManufacturerName = N'RIDBERG' AND s.SupplierName = N'KRYLOVMANUFACTURA';
GO

-- ===================== Пользователи (user_import.xlsx, 10 строк) =====================
-- Пароли хранятся открытым текстом — хеширование не требуется (подтверждено).
-- Логин в приложении сравнивает Login+Password напрямую с этой таблицей.

INSERT INTO Users (FullName, Login, Password, RoleId)
SELECT N'Никифорова Анна Семеновна', N'94d5ous@gmail.com', N'uzWC67', r.RoleId FROM Roles r WHERE r.RoleName = N'Администратор';
INSERT INTO Users (FullName, Login, Password, RoleId)
SELECT N'Стелина Евгения Петровна', N'uth4iz@mail.com', N'2L6KZG', r.RoleId FROM Roles r WHERE r.RoleName = N'Администратор';
INSERT INTO Users (FullName, Login, Password, RoleId)
SELECT N'Никифорова Весения Николаевна', N'5d4zbu@tutanota.com', N'rwVDh9', r.RoleId FROM Roles r WHERE r.RoleName = N'Администратор';
INSERT INTO Users (FullName, Login, Password, RoleId)
SELECT N'Сазонов Руслан Германович', N'ptec8ym@yahoo.com', N'LdNyos', r.RoleId FROM Roles r WHERE r.RoleName = N'Менеджер';
INSERT INTO Users (FullName, Login, Password, RoleId)
SELECT N'Одинцов Серафим Артёмович', N'1qz4kw@mail.com', N'gynQMT', r.RoleId FROM Roles r WHERE r.RoleName = N'Менеджер';
INSERT INTO Users (FullName, Login, Password, RoleId)
SELECT N'Старикова Елена Павловна', N'4np6se@mail.com', N'AtnDjr', r.RoleId FROM Roles r WHERE r.RoleName = N'Менеджер';
INSERT INTO Users (FullName, Login, Password, RoleId)
SELECT N'Степанов Михаил Артёмович', N'yzls62@outlook.com', N'JlFRCZ', r.RoleId FROM Roles r WHERE r.RoleName = N'Авторизированный клиент';
INSERT INTO Users (FullName, Login, Password, RoleId)
SELECT N'Михайлюк Анна Вячеславовна', N'1diph5e@tutanota.com', N'8ntwUp', r.RoleId FROM Roles r WHERE r.RoleName = N'Авторизированный клиент';
INSERT INTO Users (FullName, Login, Password, RoleId)
SELECT N'Ситдикова Елена Анатольевна', N'tjde7c@yahoo.com', N'YOyhfR', r.RoleId FROM Roles r WHERE r.RoleName = N'Авторизированный клиент';
INSERT INTO Users (FullName, Login, Password, RoleId)
SELECT N'Ворсин Петр Евгеньевич', N'wpmrc3do@tutanota.com', N'RSbvHv', r.RoleId FROM Roles r WHERE r.RoleName = N'Авторизированный клиент';
GO

-- ===================== Пункты выдачи (Пункты выдачи_import.xlsx, 36 строк) =====================

INSERT INTO PickupPoints (Address) VALUES
(N'420151, г. Лесной, ул. Вишневая, 32'),
(N'125061, г. Лесной, ул. Подгорная, 8'),
(N'630370, г. Лесной, ул. Шоссейная, 24'),
(N'400562, г. Лесной, ул. Зеленая, 32'),
(N'614510, г. Лесной, ул. Маяковского, 47'),
(N'410542, г. Лесной, ул. Светлая, 46'),
(N'620839, г. Лесной, ул. Цветочная, 8'),
(N'443890, г. Лесной, ул. Коммунистическая, 1'),
(N'603379, г. Лесной, ул. Спортивная, 46'),
(N'603721, г. Лесной, ул. Гоголя, 41'),
(N'410172, г. Лесной, ул. Северная, 13'),
(N'614611, г. Лесной, ул. Молодежная, 50'),
(N'454311, г.Лесной, ул. Новая, 19'),
(N'660007, г.Лесной, ул. Октябрьская, 19'),
(N'603036, г. Лесной, ул. Садовая, 4'),
(N'394060, г.Лесной, ул. Фрунзе, 43'),
(N'410661, г. Лесной, ул. Школьная, 50'),
(N'625590, г. Лесной, ул. Коммунистическая, 20'),
(N'625683, г. Лесной, ул. 8 Марта'),
(N'450983, г.Лесной, ул. Комсомольская, 26'),
(N'394782, г. Лесной, ул. Чехова, 3'),
(N'603002, г. Лесной, ул. Дзержинского, 28'),
(N'450558, г. Лесной, ул. Набережная, 30'),
(N'344288, г. Лесной, ул. Чехова, 1'),
(N'614164, г.Лесной, ул. Степная, 30'),
(N'394242, г. Лесной, ул. Коммунистическая, 43'),
(N'660540, г. Лесной, ул. Солнечная, 25'),
(N'125837, г. Лесной, ул. Шоссейная, 40'),
(N'125703, г. Лесной, ул. Партизанская, 49'),
(N'625283, г. Лесной, ул. Победы, 46'),
(N'614753, г. Лесной, ул. Полевая, 35'),
(N'426030, г. Лесной, ул. Маяковского, 44'),
(N'450375, г. Лесной ул. Клубная, 44'),
(N'625560, г. Лесной, ул. Некрасова, 12'),
(N'630201, г. Лесной, ул. Комсомольская, 17'),
(N'190949, г. Лесной, ул. Мичурина, 26');
GO

-- ===================== Заказы (Заказ_import.xlsx, 10 строк) =====================
-- Заказ №7: исходная дата заказа в файле — "30.02.2024" (невалидная дата, 30 февраля не существует).
-- Скорректировано на 2024-02-29 (последний реальный день февраля 2024, високосный год).

INSERT INTO Orders (OrderDate, DeliveryDate, PickupCode, OrderStatusId, ClientId, PickupPointId)
SELECT '2024-02-27', '2024-04-20', 901, os.OrderStatusId, u.UserId, pp.PickupPointId
FROM OrderStatuses os, Users u, PickupPoints pp
WHERE os.StatusName = N'Новый' AND u.FullName = N'Степанов Михаил Артёмович' AND pp.PickupPointId = 1;

INSERT INTO Orders (OrderDate, DeliveryDate, PickupCode, OrderStatusId, ClientId, PickupPointId)
SELECT '2024-09-28', '2024-04-21', 902, os.OrderStatusId, u.UserId, pp.PickupPointId
FROM OrderStatuses os, Users u, PickupPoints pp
WHERE os.StatusName = N'Новый' AND u.FullName = N'Михайлюк Анна Вячеславовна' AND pp.PickupPointId = 11;

INSERT INTO Orders (OrderDate, DeliveryDate, PickupCode, OrderStatusId, ClientId, PickupPointId)
SELECT '2024-03-21', '2024-04-22', 903, os.OrderStatusId, u.UserId, pp.PickupPointId
FROM OrderStatuses os, Users u, PickupPoints pp
WHERE os.StatusName = N'Новый' AND u.FullName = N'Ситдикова Елена Анатольевна' AND pp.PickupPointId = 2;

INSERT INTO Orders (OrderDate, DeliveryDate, PickupCode, OrderStatusId, ClientId, PickupPointId)
SELECT '2024-02-20', '2024-04-23', 904, os.OrderStatusId, u.UserId, pp.PickupPointId
FROM OrderStatuses os, Users u, PickupPoints pp
WHERE os.StatusName = N'Завершен' AND u.FullName = N'Ворсин Петр Евгеньевич' AND pp.PickupPointId = 11;

INSERT INTO Orders (OrderDate, DeliveryDate, PickupCode, OrderStatusId, ClientId, PickupPointId)
SELECT '2024-03-17', '2024-04-24', 905, os.OrderStatusId, u.UserId, pp.PickupPointId
FROM OrderStatuses os, Users u, PickupPoints pp
WHERE os.StatusName = N'Завершен' AND u.FullName = N'Степанов Михаил Артёмович' AND pp.PickupPointId = 2;

INSERT INTO Orders (OrderDate, DeliveryDate, PickupCode, OrderStatusId, ClientId, PickupPointId)
SELECT '2024-03-01', '2024-04-25', 906, os.OrderStatusId, u.UserId, pp.PickupPointId
FROM OrderStatuses os, Users u, PickupPoints pp
WHERE os.StatusName = N'Завершен' AND u.FullName = N'Михайлюк Анна Вячеславовна' AND pp.PickupPointId = 15;

INSERT INTO Orders (OrderDate, DeliveryDate, PickupCode, OrderStatusId, ClientId, PickupPointId)
SELECT '2024-02-29', '2024-04-26', 907, os.OrderStatusId, u.UserId, pp.PickupPointId
FROM OrderStatuses os, Users u, PickupPoints pp
WHERE os.StatusName = N'Завершен' AND u.FullName = N'Ситдикова Елена Анатольевна' AND pp.PickupPointId = 3;

INSERT INTO Orders (OrderDate, DeliveryDate, PickupCode, OrderStatusId, ClientId, PickupPointId)
SELECT '2024-03-31', '2024-04-27', 908, os.OrderStatusId, u.UserId, pp.PickupPointId
FROM OrderStatuses os, Users u, PickupPoints pp
WHERE os.StatusName = N'Новый' AND u.FullName = N'Ворсин Петр Евгеньевич' AND pp.PickupPointId = 19;

INSERT INTO Orders (OrderDate, DeliveryDate, PickupCode, OrderStatusId, ClientId, PickupPointId)
SELECT '2024-04-02', '2024-04-28', 909, os.OrderStatusId, u.UserId, pp.PickupPointId
FROM OrderStatuses os, Users u, PickupPoints pp
WHERE os.StatusName = N'Новый' AND u.FullName = N'Ситдикова Елена Анатольевна' AND pp.PickupPointId = 5;

INSERT INTO Orders (OrderDate, DeliveryDate, PickupCode, OrderStatusId, ClientId, PickupPointId)
SELECT '2024-04-03', '2024-04-29', 910, os.OrderStatusId, u.UserId, pp.PickupPointId
FROM OrderStatuses os, Users u, PickupPoints pp
WHERE os.StatusName = N'Новый' AND u.FullName = N'Ворсин Петр Евгеньевич' AND pp.PickupPointId = 19;
GO

-- ===================== Позиции заказов (раскладка строки "Артикул заказа, кол-во, ...") =====================

INSERT INTO OrderItems (OrderId, ProductId, Quantity)
SELECT o.OrderId, p.ProductId, v.Quantity
FROM (VALUES
    (901, N'А112Т4', 2), (901, N'G843H5', 2),
    (902, N'G843H5', 1), (902, N'А112Т4', 1),
    (903, N'D325D4', 10), (903, N'S432T5', 10),
    (904, N'F325D4', 5),  (904, N'D325D4', 4),
    (905, N'G432G6', 20), (905, N'H542F5', 20),
    (906, N'А112Т4', 2),  (906, N'G843H5', 2),
    (907, N'G843H5', 1),  (907, N'А112Т4', 1),
    (908, N'D325D4', 10), (908, N'S432T5', 10),
    (909, N'F325D4', 5),  (909, N'D325D4', 4),
    (910, N'G432G6', 20), (910, N'H542F5', 20)
) AS v(PickupCode, Article, Quantity)
JOIN Orders   o ON o.PickupCode = v.PickupCode
JOIN Products p ON p.Article    = v.Article;
GO