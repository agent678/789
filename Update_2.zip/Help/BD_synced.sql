USE master;
GO

IF DB_ID('MebelStore') IS NOT NULL
BEGIN
    ALTER DATABASE MebelStore SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE MebelStore;
END
GO

CREATE DATABASE MebelStore;
GO

USE MebelStore;
GO

CREATE TABLE Roles (
    RoleID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Roles PRIMARY KEY,
    RoleName NVARCHAR(100) NOT NULL CONSTRAINT UQ_Roles_RoleName UNIQUE
);
GO

CREATE TABLE Users (
    UserID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
    RoleID INT NOT NULL,
    FullName NVARCHAR(150) NOT NULL,
    Login NVARCHAR(100) NOT NULL CONSTRAINT UQ_Users_Login UNIQUE,
    [Password] NVARCHAR(100) NOT NULL,
    CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleID) REFERENCES Roles(RoleID)
);
GO

CREATE TABLE FurnitureProducts (
    Article NVARCHAR(20) NOT NULL CONSTRAINT PK_FurnitureProducts PRIMARY KEY,
    ProductName NVARCHAR(300) NOT NULL,
    Unit NVARCHAR(20) NOT NULL,
    Price DECIMAL(10,2) NOT NULL CONSTRAINT CK_FurnitureProducts_Price CHECK (Price >= 0),
    Supplier NVARCHAR(150) NOT NULL,
    Manufacturer NVARCHAR(150) NOT NULL,
    Category NVARCHAR(100) NOT NULL,
    Discount DECIMAL(5,2) NOT NULL CONSTRAINT CK_FurnitureProducts_Discount CHECK (Discount >= 0 AND Discount <= 100),
    StockQuantity INT NOT NULL CONSTRAINT CK_FurnitureProducts_StockQuantity CHECK (StockQuantity >= 0),
    [Description] NVARCHAR(MAX) NULL,
    Photo NVARCHAR(255) NULL
);
GO

CREATE TABLE PickupPoints (
    PickupPointID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_PickupPoints PRIMARY KEY,
    [Address] NVARCHAR(255) NOT NULL
);
GO

CREATE TABLE Orders (
    OrderID INT NOT NULL CONSTRAINT PK_Orders PRIMARY KEY,
    OrderDate DATE NOT NULL,
    DeliveryDate DATE NOT NULL,
    PickupPointID INT NOT NULL,
    UserID INT NOT NULL,
    ReceiveCode NVARCHAR(20) NOT NULL,
    OrderStatus NVARCHAR(50) NOT NULL,
    CONSTRAINT FK_Orders_PickupPoints FOREIGN KEY (PickupPointID) REFERENCES PickupPoints(PickupPointID),
    CONSTRAINT FK_Orders_Users FOREIGN KEY (UserID) REFERENCES Users(UserID)
);
GO

CREATE TABLE OrderItems (
    OrderID INT NOT NULL,
    Article NVARCHAR(20) NOT NULL,
    Quantity INT NOT NULL CONSTRAINT CK_OrderItems_Quantity CHECK (Quantity > 0),
    CONSTRAINT PK_OrderItems PRIMARY KEY (OrderID, Article),
    CONSTRAINT FK_OrderItems_Orders FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    CONSTRAINT FK_OrderItems_FurnitureProducts FOREIGN KEY (Article) REFERENCES FurnitureProducts(Article)
);
GO

INSERT INTO Roles (RoleName) VALUES
(N'Администратор'),
(N'Менеджер'),
(N'Авторизированный клиент');
GO

INSERT INTO Users (RoleID, FullName, Login, [Password]) VALUES
(1, N'Никифорова Анна Семеновна', N'94d5ous@gmail.com', N'uzWC67'),
(1, N'Стелина Евгения Петровна', N'uth4iz@mail.com', N'2L6KZG'),
(1, N'Никифорова Весения Николаевна', N'5d4zbu@tutanota.com', N'rwVDh9'),
(2, N'Сазонов Руслан Германович', N'ptec8ym@yahoo.com', N'LdNyos'),
(2, N'Одинцов Серафим Артёмович', N'1qz4kw@mail.com', N'gynQMT'),
(2, N'Старикова Елена Павловна', N'4np6se@mail.com', N'AtnDjr'),
(3, N'Степанов Михаил Артёмович', N'yzls62@outlook.com', N'JlFRCZ'),
(3, N'Михайлюк Анна Вячеславовна', N'1diph5e@tutanota.com', N'8ntwUp'),
(3, N'Ситдикова Елена Анатольевна', N'tjde7c@yahoo.com', N'YOyhfR'),
(3, N'Ворсин Петр Евгеньевич', N'wpmrc3do@tutanota.com', N'RSbvHv');
GO

INSERT INTO FurnitureProducts 
(Article, ProductName, Unit, Price, Supplier, Manufacturer, Category, Discount, StockQuantity, [Description], Photo) 
VALUES
(N'А112Т4', N'Прихожая Фаворит 1 1420х2056х352мм Дуб Делано/Цемент Светлый SV-М', N'шт.', 9577.00, N'Стройландия', N'SVМЕБЕЛЬ', N'Прихожая', 10.00, 0, N'Функциональная и практичная прихожая для хранения одежды и обуви.', N'1.jpg'),
(N'G843H5', N'Прихожая в коридор Твист с зеркалом и шкафами 120х37х202 см', N'шт.', 8803.00, N'Стройландия', N'Мебелони', N'Прихожая', 25.00, 9, N'Стеллаж со шкафом в прихожую комнату.', N'2.jpg'),
(N'D325D4', N'Угловой диван Кромма Инвуд Лайт серый двухместный Velutto 32', N'шт.', 29125.00, N'Кромма', N'Инвуд', N'Диван', 5.00, 12, N'Стильный и комфортный угловой диван для комнаты.', N'3.jpg'),
(N'S432T5', N'Обувница RIDBERG с вешалкой стальная 170x60x26 см 5 полок', N'шт.', 885.00, N'Кромма', N'RIDBERG', N'Обувница', 15.00, 15, N'Обувница с пятью полками и вешалкой.', N'4.jpg'),
(N'F325D4', N'Диван-кровать Сити темно-коричневый Квест-33', N'шт.', 14322.00, N'ЗолотоеРуно', N'Инвуд', N'Диван', 18.00, 3, N'Современный прямой диван-кровать для гостиной.', N'5.jpg'),
(N'G432G6', N'Пуф трансформер кровать раскладушка светло-коричневый велюр', N'шт.', 6149.00, N'KRYLOVMANUFACTURA', N'Инвуд', N'Пуф', 22.00, 3, N'Пуф-трансформер сочетает несколько функций.', N'6.jpg'),
(N'H542F5', N'Диван Рио Симпл механизм Пантограф Симпл-16', N'шт.', 20708.00, N'ЗолотоеРуно', N'Инвуд', N'Диван', 4.00, 5, N'Диван с удобным механизмом трансформации.', N'7.jpg'),
(N'C346F5', N'Полка настенная ромб Лофт черная 40 см', N'шт.', 2843.00, N'KRYLOVMANUFACTURA', N'RIDBERG', N'Полка', 5.00, 4, N'Настенная полка в стиле лофт.', N'8.jpg'),
(N'F256G6', N'Стулья для кухни комплект', N'шт.', 4760.00, N'KRYLOVMANUFACTURA', N'RIDBERG', N'Стул', 6.00, 2, N'Набор стульев в лофт-дизайне.', N'9.jpg'),
(N'J532V5', N'Магнитная полка для холодильника металл 3 шт универсальная черная', N'шт.', 1387.00, N'KRYLOVMANUFACTURA', N'RIDBERG', N'Полка', 8.00, 6, N'Практичная металлическая магнитная полка.', N'10.jpg');
GO

INSERT INTO PickupPoints ([Address]) VALUES
(N'420151, г. Лесной, ул. Вишневая, 32'),
(N'125061, г. Лесной, ул. Подгорная, 8'),
(N'630370, г. Лесной, ул. Шоссейная, 24'),
(N'400562, г. Лесной, ул. Зеленая, 32'),
(N'614510, г. Лесной, ул. Маяковского, 47');
GO

INSERT INTO Orders (OrderID, OrderDate, DeliveryDate, PickupPointID, UserID, ReceiveCode, OrderStatus) VALUES
(1, '2024-02-27', '2024-04-20', 1, 7, N'901', N'Новый'),
(2, '2024-09-28', '2024-04-21', 2, 8, N'902', N'Новый'),
(3, '2024-03-21', '2024-04-22', 3, 9, N'903', N'Новый'),
(4, '2024-02-20', '2024-04-23', 4, 10, N'904', N'Завершен'),
(5, '2024-03-17', '2024-04-24', 5, 7, N'905', N'Завершен');
GO

INSERT INTO OrderItems (OrderID, Article, Quantity) VALUES
(1, N'А112Т4', 2),
(1, N'G843H5', 2),
(2, N'G843H5', 1),
(2, N'А112Т4', 1),
(3, N'D325D4', 10),
(3, N'S432T5', 10),
(4, N'F325D4', 5),
(4, N'D325D4', 4),
(5, N'G432G6', 20),
(5, N'H542F5', 20);
GO

SELECT * FROM Roles;
SELECT * FROM Users;
SELECT * FROM FurnitureProducts;
SELECT * FROM PickupPoints;
SELECT * FROM Orders;
SELECT * FROM OrderItems;
GO

/* Данные перенесены из файла "BD — копия.sql" */

INSERT INTO PickupPoints ([Address]) VALUES
(N'410542, г. Лесной, ул. Светлая, 46'),
(N'620839, г. Лесной, ул. Цветочная, 8'),
(N'443890, г. Лесной, ул. Коммунистическая, 1'),
(N'603379, г. Лесной, ул. Спортивная, 46'),
(N'603721, г. Лесной, ул. Гоголя, 41'),
(N'410172, г. Лесной, ул. Северная, 13'),
(N'614611, г. Лесной, ул. Молодежная, 50'),
(N'454311, г.Лесной, ул. Новая, 19'),
(N'660007, г.Лесной, ул. Октябрьская, 19'),
(N'603036, г. Лесной, ул. Садовая, 4'),
(N'394060, г.Лесной, ул. Фрунзе, 43'),
(N'410661, г. Лесной, ул. Школьная, 50'),
(N'625590, г. Лесной, ул. Коммунистическая, 20'),
(N'625683, г. Лесной, ул. 8 Марта'),
(N'450983, г.Лесной, ул. Комсомольская, 26'),
(N'394782, г. Лесной, ул. Чехова, 3'),
(N'603002, г. Лесной, ул. Дзержинского, 28'),
(N'450558, г. Лесной, ул. Набережная, 30'),
(N'344288, г. Лесной, ул. Чехова, 1'),
(N'614164, г.Лесной, ул. Степная, 30'),
(N'394242, г. Лесной, ул. Коммунистическая, 43'),
(N'660540, г. Лесной, ул. Солнечная, 25'),
(N'125837, г. Лесной, ул. Шоссейная, 40'),
(N'125703, г. Лесной, ул. Партизанская, 49'),
(N'625283, г. Лесной, ул. Победы, 46'),
(N'614753, г. Лесной, ул. Полевая, 35'),
(N'426030, г. Лесной, ул. Маяковского, 44'),
(N'450375, г. Лесной ул. Клубная, 44'),
(N'625560, г. Лесной, ул. Некрасова, 12'),
(N'630201, г. Лесной, ул. Комсомольская, 17'),
(N'190949, г. Лесной, ул. Мичурина, 26');
GO

INSERT INTO Orders (OrderID, OrderDate, DeliveryDate, PickupPointID, UserID, ReceiveCode, OrderStatus) VALUES
(6, '2024-03-01', '2024-04-25', 15, 8, N'906', N'Завершен'),
(7, '2024-02-29', '2024-04-26', 3, 9, N'907', N'Завершен'),
(8, '2024-03-31', '2024-04-27', 4, 10, N'908', N'Новый'),
(9, '2024-04-02', '2024-04-28', 5, 9, N'909', N'Новый'),
(10, '2024-04-03', '2024-04-29', 6, 10, N'910', N'Новый');
GO

INSERT INTO OrderItems (OrderID, Article, Quantity) VALUES
(6, N'А112Т4', 2),
(6, N'G843H5', 2),
(7, N'G843H5', 1),
(7, N'А112Т4', 1),
(8, N'D325D4', 10),
(8, N'S432T5', 10),
(9, N'F325D4', 5),
(9, N'D325D4', 4),
(10, N'G432G6', 20),
(10, N'H542F5', 20);
GO
